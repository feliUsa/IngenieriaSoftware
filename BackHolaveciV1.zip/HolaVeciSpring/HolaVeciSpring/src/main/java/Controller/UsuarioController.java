package Controller;

import Model.Usuario;
import Services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@RestController
@RequestMapping("/Usuarios") //Nombre tabla usuarios en DB
public class UsuarioController {

    @Autowired
    UsuarioService ur;

    // Leer todos los usuarios
    @GetMapping()
    public ArrayList<Usuario> readUsers(){
        return ur.read();
    }

    @GetMapping(path = "/{id}")
    public Optional<Usuario> buscarPorId(@PathVariable("id") int id){
        return this.ur.ObtenerPorId(id);
    }

    @GetMapping("/query")
    public ArrayList<Usuario> buscarPorEmail(@RequestParam("email") String correo){
        return this.ur.obtenerPorEmail(correo);
    }

    // Guardar Usuario
    @PostMapping()
    public Usuario saveUsers(@RequestBody Usuario u){
        return this.ur.save(u);
    }

    @DeleteMapping(path = "/{id}")
    public String eliminarPorId(@PathVariable("id") int id){
        boolean ok = this.ur.delete(id);
        if (ok){
            return "Se elimino el usuario con id "+id;
        }else{
            return "No se pudo eliminar el usuario con id "+id;
        }
    }
}
