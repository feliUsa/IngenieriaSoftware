package Model;

import jakarta.persistence.*;

@Entity
@Table(name = "usuarios") //Nombre tabla en la DB
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private String email;
    private String nombre;
    private String nombreUsuario;
    private String contra;

    public Usuario(){

    }

    public Usuario(int id, String email, String nombre, String nombreUsuario, String contra) {
        this.id = id;
        this.email = email;
        this.nombre = nombre;
        this.nombreUsuario = nombreUsuario;
        this.contra = contra;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }
}
