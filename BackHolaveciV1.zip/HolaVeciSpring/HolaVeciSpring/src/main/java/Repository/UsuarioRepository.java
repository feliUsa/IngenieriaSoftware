package Repository;

import Model.Usuario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface UsuarioRepository extends CrudRepository<Usuario, Integer> {
    public abstract ArrayList<Usuario> obtenerPorEmail(String correo);
}
