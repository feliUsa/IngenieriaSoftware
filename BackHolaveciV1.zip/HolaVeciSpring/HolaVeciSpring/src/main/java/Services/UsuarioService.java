package Services;

import Model.Usuario;
import Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    UsuarioRepository ur;

    //Lista Usuarios - Read

    public ArrayList<Usuario> read(){
        return (ArrayList<Usuario>) ur.findAll();
    }

    public Optional<Usuario> ObtenerPorId(int id){
        return ur.findById(id);
    }

    public ArrayList<Usuario> obtenerPorEmail (String correo){
        return ur.obtenerPorEmail(correo);
    }

    // Guardar Usuario
    public Usuario save(Usuario u){
        return ur.save(u);
    }

    public boolean delete(int id){
        try{
            ur.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }




}
