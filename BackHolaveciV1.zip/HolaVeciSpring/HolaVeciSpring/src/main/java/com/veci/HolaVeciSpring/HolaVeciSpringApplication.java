package com.veci.HolaVeciSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaVeciSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaVeciSpringApplication.class, args);
	}

}
